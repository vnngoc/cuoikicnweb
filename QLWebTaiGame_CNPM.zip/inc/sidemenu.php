<div class="sidebar">
		<div class="tlt">
			Quản lý
		</div>
		<ul>
			<li><a href="./admin-index.php"><i class="fas fa-qrcode"></i>Dashboard</a></li>
			<li><a href="./List_game.php"><i class="fa-solid fa-chess-rook"></i>Game</a></li>
			<li><a href="./List_user.php"><i class="fa-solid fa-user"></i>Người dùng</a></li>
			<li><a href="./List_category.php"><i class="fa-solid fa-list-ul"></i>Thể loại</a></li>
		</ul>
</div>